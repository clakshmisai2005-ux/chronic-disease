"""
app.py
======
Streamlit dashboard for the AI-Driven Predictive Analytics for Early
Diagnosis and Personalized Treatment in Chronic Diseases project.

Run with:
    streamlit run app/app.py

Pages:
    1. Home / Project Overview
    2. Risk Prediction
    3. Explainability
    4. Personalized Recommendations
    5. Model Performance
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
import streamlit as st

# ---------------------------------------------------------------------------
# Make src/ importable regardless of the working directory Streamlit is
# launched from.
# ---------------------------------------------------------------------------
PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

from src.explainability import compute_feature_importance, TREE_BASED_MODELS  # noqa: E402
from src.recommendations import generate_recommendations, format_recommendations_markdown  # noqa: E402
from src.preprocessing import run_preprocessing_pipeline  # noqa: E402

MODELS_DIR = PROJECT_ROOT / "models"
RESULTS_DIR = PROJECT_ROOT / "results"
BEST_MODEL_PATH = MODELS_DIR / "best_model.pkl"
SCALER_PATH = MODELS_DIR / "scaler.pkl"
METADATA_PATH = MODELS_DIR / "model_metadata.pkl"
FEATURE_INFO_PATH = MODELS_DIR / "feature_info.json"

st.set_page_config(
    page_title="Chronic Disease Risk Predictor",
    page_icon="🩺",
    layout="wide",
)

DISCLAIMER_BANNER = (
    "⚠️ **Research / Decision-Support Tool Only.** This application is an "
    "academic project and does **not** provide a medical diagnosis. "
    "Predictions and recommendations are based on statistical patterns in a "
    "training dataset and must not replace consultation with a qualified "
    "healthcare professional."
)


# ---------------------------------------------------------------------------
# Cached loaders
# ---------------------------------------------------------------------------
@st.cache_resource
def load_artifacts():
    """Load model, scaler, metadata, and feature info once and cache them."""
    missing = [p for p in [BEST_MODEL_PATH, SCALER_PATH, METADATA_PATH, FEATURE_INFO_PATH] if not p.exists()]
    if missing:
        return None

    model = joblib.load(BEST_MODEL_PATH)
    scaler = joblib.load(SCALER_PATH)
    metadata = joblib.load(METADATA_PATH)
    with open(FEATURE_INFO_PATH) as f:
        feature_info = json.load(f)
    return {"model": model, "scaler": scaler, "metadata": metadata, "feature_info": feature_info}


@st.cache_data
def load_test_split():
    """Reload the same train/test split used for training, for evaluation display."""
    X_train, X_test, y_train, y_test, scaler, target_col = run_preprocessing_pipeline(save_outputs=False)
    return X_train, X_test, y_train, y_test, target_col


@st.cache_data
def compute_importance_cached(_model, _X_train, _X_test, _y_test, feature_names):
    return compute_feature_importance(_model, _X_train, _X_test, _y_test, feature_names)


# ---------------------------------------------------------------------------
# Sidebar navigation
# ---------------------------------------------------------------------------
st.sidebar.title("🩺 Navigation")
page = st.sidebar.radio(
    "Go to",
    [
        "🏠 Home / Overview",
        "🔮 Risk Prediction",
        "🧠 Explainability",
        "💡 Recommendations",
        "📊 Model Performance",
    ],
)

artifacts = load_artifacts()

if artifacts is None:
    st.error(
        "Model artifacts not found. Please run the training pipeline first:\n\n"
        "```bash\npython -m src.train_model\n```"
    )
    st.stop()

model = artifacts["model"]
scaler = artifacts["scaler"]
metadata = artifacts["metadata"]
feature_info = artifacts["feature_info"]
feature_names = feature_info["feature_names"]
target_col = feature_info["target_column"]

# Keep the last prediction in session state so it can be reused across the
# Explainability and Recommendations pages without re-entering inputs.
if "last_prediction" not in st.session_state:
    st.session_state["last_prediction"] = None


# ---------------------------------------------------------------------------
# PAGE 1: Home / Overview
# ---------------------------------------------------------------------------
if page == "🏠 Home / Overview":
    st.title("AI-Driven Predictive Analytics for Chronic Disease Risk")
    st.markdown(
        "### Early Diagnosis Support & Personalized Health Recommendations"
    )
    st.warning(DISCLAIMER_BANNER)

    col1, col2 = st.columns([2, 1])
    with col1:
        st.subheader("Project Objective")
        st.write(
            "This project applies machine learning to patient health data to "
            "estimate the likelihood of a chronic disease (diabetes) and "
            "explain the key factors behind each prediction, in order to "
            "support -- not replace -- early screening and lifestyle guidance."
        )

        st.subheader("Problem Statement")
        st.write(
            "Chronic diseases such as diabetes often develop silently and are "
            "diagnosed late. Early, data-driven risk estimation combined with "
            "explainable, personalized guidance can help individuals and "
            "clinicians prioritize further screening."
        )

        st.subheader("Workflow")
        st.markdown(
            """
            1. **Data Preprocessing** — cleaning, handling missing/invalid values, scaling
            2. **Exploratory Data Analysis** — understanding feature distributions & relationships
            3. **Model Training** — comparing multiple ML algorithms
            4. **Model Evaluation** — accuracy, precision, recall, F1, ROC-AUC
            5. **Explainable AI** — identifying influential features per prediction
            6. **Personalized Recommendations** — general, educational lifestyle guidance
            7. **Interactive Dashboard** — this Streamlit application
            """
        )

    with col2:
        st.subheader("Technology Stack")
        st.markdown(
            """
            - **Language:** Python 3.11+
            - **Data:** pandas, numpy
            - **ML:** scikit-learn
            - **Explainability:** SHAP / permutation / coefficients
            - **Visualization:** matplotlib, seaborn
            - **App:** Streamlit
            """
        )

        st.subheader("Current Best Model")
        st.metric("Selected Model", metadata["model_name"])
        st.metric("Cross-Val ROC-AUC", f"{metadata['metrics']['cv_roc_auc_mean']:.3f}")
        st.metric("Test F1-Score", f"{metadata['metrics']['test_f1']:.3f}")

    st.divider()
    st.info(DISCLAIMER_BANNER)


# ---------------------------------------------------------------------------
# PAGE 2: Risk Prediction
# ---------------------------------------------------------------------------
elif page == "🔮 Risk Prediction":
    st.title("🔮 Risk Prediction")
    st.warning(DISCLAIMER_BANNER)
    st.write("Enter patient measurements below. Fields are generated dynamically from the dataset's actual features.")

    input_values = {}
    n_cols = 2
    cols = st.columns(n_cols)
    for i, feat in enumerate(feature_names):
        rng = feature_info["feature_ranges"][feat]
        col = cols[i % n_cols]
        with col:
            # Use integer widgets for features that look integer-valued in the
            # original ranges (e.g. Age, Pregnancies); float otherwise.
            is_integer_like = float(rng["mean"]).is_integer() and float(rng["min"]).is_integer() and float(rng["max"]).is_integer()
            default_val = float(rng["mean"])
            if is_integer_like:
                input_values[feat] = st.number_input(
                    feat, min_value=0, max_value=int(rng["max"]) * 2 if rng["max"] > 0 else 100,
                    value=int(round(default_val)), step=1,
                )
            else:
                input_values[feat] = st.number_input(
                    feat, min_value=0.0, value=round(default_val, 2), step=0.1, format="%.2f",
                )

    if st.button("Predict Risk", type="primary"):
        input_df = pd.DataFrame([input_values])[feature_names]
        numeric_cols = feature_info["numeric_columns"]
        scaled_df = input_df.copy()
        scaled_df[numeric_cols] = scaler.transform(input_df[numeric_cols])

        prediction = int(model.predict(scaled_df)[0])
        probability = float(model.predict_proba(scaled_df)[0][1])

        st.session_state["last_prediction"] = {
            "input_df": input_df,
            "scaled_df": scaled_df,
            "prediction": prediction,
            "probability": probability,
        }

        st.divider()
        st.subheader("Prediction Result")

        col1, col2, col3 = st.columns(3)
        with col1:
            label = "At Risk" if prediction == 1 else "Not At Risk"
            st.metric("Predicted Class", label)
        with col2:
            st.metric("Risk Probability", f"{probability:.1%}")
        with col3:
            if probability < 0.33:
                category, color = "Low", "🟢"
            elif probability < 0.66:
                category, color = "Moderate", "🟡"
            else:
                category, color = "High", "🔴"
            st.metric("Risk Category", f"{color} {category}")

        st.progress(min(max(probability, 0.0), 1.0))
        st.caption(
            "This estimate reflects statistical patterns learned from a training "
            "dataset. It is not a diagnosis. Go to the **Explainability** and "
            "**Recommendations** pages to learn more about this result."
        )


# ---------------------------------------------------------------------------
# PAGE 3: Explainability
# ---------------------------------------------------------------------------
elif page == "🧠 Explainability":
    st.title("🧠 Explainability")
    st.warning(DISCLAIMER_BANNER)

    X_train, X_test, y_train, y_test, _ = load_test_split()
    importances = compute_importance_cached(model, X_train, X_test, y_test, tuple(feature_names))
    importances = pd.Series(importances) if not isinstance(importances, pd.Series) else importances

    st.subheader("Global Feature Importance")
    st.write(
        "These are the features the model, overall, relied on most heavily "
        "when making predictions across the dataset. Importance reflects "
        "statistical association learned by the model -- it does not prove "
        "that a feature *causes* the outcome."
    )

    fi_image_path = RESULTS_DIR / "feature_importance.png"
    if fi_image_path.exists():
        st.image(str(fi_image_path), caption="Feature Importance (generated during training)", use_container_width=True)
    else:
        st.bar_chart(importances.sort_values(ascending=False))

    st.divider()
    st.subheader("Explanation for Your Last Prediction")

    if st.session_state["last_prediction"] is None:
        st.info("Go to the **Risk Prediction** page and submit patient values first to see a personalized explanation.")
    else:
        pred_info = st.session_state["last_prediction"]
        top_features = importances.sort_values(ascending=False).head(5)

        st.write(
            f"For the patient you entered, the model predicted "
            f"**{'At Risk' if pred_info['prediction'] == 1 else 'Not At Risk'}** "
            f"with a probability of **{pred_info['probability']:.1%}**. "
            f"The features below were most influential in the model overall, "
            f"shown alongside the values you entered:"
        )

        explain_df = pd.DataFrame(
            {
                "Feature": top_features.index,
                "Importance": top_features.values,
                "Value Entered": [pred_info["input_df"][f].values[0] for f in top_features.index],
            }
        )
        st.dataframe(explain_df, use_container_width=True, hide_index=True)


# ---------------------------------------------------------------------------
# PAGE 4: Personalized Recommendations
# ---------------------------------------------------------------------------
elif page == "💡 Recommendations":
    st.title("💡 Personalized Recommendations")
    st.warning(DISCLAIMER_BANNER)

    if st.session_state["last_prediction"] is None:
        st.info("Go to the **Risk Prediction** page and submit patient values first to generate recommendations.")
    else:
        pred_info = st.session_state["last_prediction"]

        X_train, X_test, y_train, y_test, _ = load_test_split()
        importances = compute_importance_cached(model, X_train, X_test, y_test, tuple(feature_names))
        importances = pd.Series(importances) if not isinstance(importances, pd.Series) else importances
        top_features = importances.sort_values(ascending=False).head(5).index.tolist()

        patient_dict = pred_info["input_df"].iloc[0].to_dict()
        report = generate_recommendations(
            patient_input=patient_dict,
            top_features=top_features,
            risk_probability=pred_info["probability"],
        )

        st.markdown(format_recommendations_markdown(report))


# ---------------------------------------------------------------------------
# PAGE 5: Model Performance
# ---------------------------------------------------------------------------
elif page == "📊 Model Performance":
    st.title("📊 Model Performance")
    st.warning(DISCLAIMER_BANNER)

    st.subheader(f"Selected Model: {metadata['model_name']}")
    m = metadata["metrics"]
    col1, col2, col3, col4, col5 = st.columns(5)
    col1.metric("Accuracy", f"{m['test_accuracy']:.3f}")
    col2.metric("Precision", f"{m['test_precision']:.3f}")
    col3.metric("Recall", f"{m['test_recall']:.3f}")
    col4.metric("F1-Score", f"{m['test_f1']:.3f}")
    col5.metric("ROC-AUC", f"{m['test_roc_auc']:.3f}")

    st.divider()
    st.subheader("Model Comparison")
    comparison_csv = RESULTS_DIR / "model_comparison.csv"
    if comparison_csv.exists():
        comparison_df = pd.read_csv(comparison_csv, index_col=0)
        st.dataframe(comparison_df.round(4), use_container_width=True)
    else:
        st.info("Model comparison table not found. Run `python -m src.train_model` to generate it.")

    st.divider()
    col1, col2 = st.columns(2)
    with col1:
        st.subheader("Confusion Matrix")
        cm_path = RESULTS_DIR / "confusion_matrix.png"
        if cm_path.exists():
            st.image(str(cm_path), use_container_width=True)
        else:
            st.info("Run `python -m src.evaluate_model` to generate this plot.")
    with col2:
        st.subheader("ROC Curve")
        roc_path = RESULTS_DIR / "roc_curve.png"
        if roc_path.exists():
            st.image(str(roc_path), use_container_width=True)
        else:
            st.info("Run `python -m src.evaluate_model` to generate this plot.")

    st.caption(
        "Metrics reflect performance on a held-out test split of the training "
        "dataset only, and do not represent clinical validation."
    )
