"""
recommendations.py
===================
Generates general, educational lifestyle/health recommendations based on:
    - the model's predicted risk category
    - which patient features were most important to the prediction
    - whether the patient's entered values for those features look elevated

STRICT SCOPE LIMITS (do not change these):
    - Does NOT prescribe medicines or drug dosages.
    - Does NOT diagnose disease.
    - Does NOT replace a doctor.
    - Always labels output as general educational guidance, not medical advice.

Recommendation rules are keyed on common clinical feature names (as found in
the Pima Indians Diabetes dataset). Features not covered by a specific rule
still receive a generic monitoring recommendation, so the module degrades
gracefully for other datasets with different column names.
"""

from __future__ import annotations

import pandas as pd

DISCLAIMER = (
    "These recommendations are general educational guidance generated from "
    "statistical patterns in a research dataset. They are **not** a medical "
    "diagnosis or a treatment plan, and they do not replace consultation "
    "with a qualified healthcare professional. No medications or dosages "
    "are suggested here."
)

# Reference thresholds used only to decide whether to SURFACE a tip, based
# on commonly cited general clinical reference ranges. These are simplified
# for an educational student project and are not diagnostic cutoffs.
FEATURE_TIPS = {
    "Glucose": {
        "threshold": 140,
        "high": (
            "Your entered glucose value is on the higher side. Consider reducing "
            "intake of refined sugars and simple carbohydrates, and discuss "
            "blood glucose monitoring with a healthcare professional."
        ),
    },
    "BMI": {
        "threshold": 30,
        "high": (
            "Your BMI falls in a range associated with elevated health risk. "
            "A gradual, sustainable approach to weight management -- balanced "
            "nutrition and regular physical activity -- is generally recommended, "
            "ideally guided by a healthcare professional or dietitian."
        ),
    },
    "BloodPressure": {
        "threshold": 90,
        "high": (
            "Your entered blood pressure value is on the higher side. Reducing "
            "sodium intake, managing stress, and staying physically active can "
            "help, alongside regular monitoring with a healthcare provider."
        ),
    },
    "Age": {
        "threshold": 45,
        "high": (
            "Risk for many chronic conditions increases with age. Regular "
            "health check-ups and screening become increasingly valuable."
        ),
    },
    "Insulin": {
        "threshold": 166,
        "high": (
            "Your entered insulin level is on the higher side. This is worth "
            "discussing with a healthcare professional as part of a broader "
            "metabolic health assessment."
        ),
    },
    "SkinThickness": {
        "threshold": 35,
        "high": (
            "This measurement relates to body fat distribution. Regular "
            "physical activity and a balanced diet support healthy body composition."
        ),
    },
    "DiabetesPedigreeFunction": {
        "threshold": 0.8,
        "high": (
            "Your entered value suggests a stronger family history influence. "
            "Family history is not modifiable, but proactive lifestyle habits "
            "and regular screening can help manage overall risk."
        ),
    },
    "Pregnancies": {
        "threshold": 6,
        "high": (
            "A higher number of pregnancies can be associated with increased "
            "metabolic risk over time. Regular postpartum and ongoing health "
            "screening is generally beneficial."
        ),
    },
}

GENERAL_TIPS = [
    "Maintain a balanced diet rich in vegetables, whole grains, and lean protein, and limit processed/sugary foods.",
    "Aim for at least 150 minutes of moderate physical activity per week, as tolerated.",
    "Prioritize consistent sleep and stress management.",
    "Schedule regular check-ups so risk factors can be monitored over time.",
    "Avoid tobacco use and limit alcohol consumption.",
]


def categorize_risk(probability: float) -> str:
    """Convert a predicted probability into a human-readable risk category."""
    if probability < 0.33:
        return "Low"
    elif probability < 0.66:
        return "Moderate"
    else:
        return "High"


def generate_recommendations(
    patient_input: dict,
    top_features: list[str],
    risk_probability: float,
) -> dict:
    """
    Build a structured recommendation report for one patient.

    Parameters
    ----------
    patient_input : dict
        The raw feature values entered for this patient (feature_name -> value).
    top_features : list[str]
        The most important features for this prediction (from explainability.py),
        ordered by importance, most important first.
    risk_probability : float
        The model's predicted probability of the positive (disease) class.

    Returns
    -------
    dict with keys: risk_category, feature_based_tips, general_tips, disclaimer
    """
    risk_category = categorize_risk(risk_probability)
    feature_based_tips = []

    for feature in top_features:
        if feature not in patient_input:
            continue
        value = patient_input[feature]
        rule = FEATURE_TIPS.get(feature)
        if rule is not None:
            try:
                if float(value) >= rule["threshold"]:
                    feature_based_tips.append(rule["high"])
            except (TypeError, ValueError):
                continue

    if not feature_based_tips:
        feature_based_tips.append(
            "No specific elevated values were flagged among the top contributing "
            "factors, but general healthy-lifestyle habits remain beneficial."
        )

    # Always recommend professional consultation for moderate/high risk.
    if risk_category in ("Moderate", "High"):
        feature_based_tips.append(
            "Given the predicted risk level, consider discussing these results "
            "with a qualified healthcare professional for proper evaluation."
        )

    return {
        "risk_category": risk_category,
        "risk_probability": round(float(risk_probability), 4),
        "feature_based_tips": feature_based_tips,
        "general_tips": GENERAL_TIPS,
        "disclaimer": DISCLAIMER,
    }


def format_recommendations_markdown(report: dict) -> str:
    """Render a recommendation report dict as a Markdown string for display."""
    lines = [
        f"### Predicted Risk Category: **{report['risk_category']}** "
        f"(probability: {report['risk_probability']:.1%})",
        "",
        "#### Personalized observations",
    ]
    for tip in report["feature_based_tips"]:
        lines.append(f"- {tip}")

    lines.append("")
    lines.append("#### General healthy-lifestyle guidance")
    for tip in report["general_tips"]:
        lines.append(f"- {tip}")

    lines.append("")
    lines.append(f"> **Disclaimer:** {report['disclaimer']}")

    return "\n".join(lines)


if __name__ == "__main__":
    # Simple demonstration using illustrative values.
    demo_input = {"Glucose": 165, "BMI": 33.2, "Age": 52, "BloodPressure": 85}
    demo_top_features = ["Glucose", "BMI", "Age"]
    demo_report = generate_recommendations(demo_input, demo_top_features, risk_probability=0.72)
    print(format_recommendations_markdown(demo_report))
