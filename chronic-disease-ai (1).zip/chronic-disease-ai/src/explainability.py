"""
explainability.py
==================
Explainable AI (XAI) utilities for the chronic disease risk model.

Explains WHICH patient features contributed most to the model's predictions,
using a method appropriate to the selected model type:

    - Tree-based models (Random Forest, Gradient Boosting, Decision Tree):
        native `feature_importances_`
    - Linear models (Logistic Regression):
        absolute standardized coefficients
    - Any other model (SVM, KNN, etc.):
        permutation importance (model-agnostic, works for any estimator)

SHAP is used when practical/compatible to provide a more theoretically
grounded, per-feature attribution, with a safe fallback to the methods above
if SHAP is unavailable or incompatible with the model type.

IMPORTANT: feature importance shows which inputs the model relied on for its
predictions on this dataset. It does NOT prove that a feature causes the
disease outcome -- correlation in a trained model is not causation.
"""

from __future__ import annotations

import joblib
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.inspection import permutation_importance
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier

from src.preprocessing import run_preprocessing_pipeline
from src.train_model import BEST_MODEL_PATH, RESULTS_DIR

FEATURE_IMPORTANCE_PATH = RESULTS_DIR / "feature_importance.png"

TREE_BASED_MODELS = (DecisionTreeClassifier, RandomForestClassifier, GradientBoostingClassifier)


def compute_feature_importance(model, X_train, X_test, y_test, feature_names) -> pd.Series:
    """
    Compute feature importance using the most appropriate method for the
    given model type. Returns a pandas Series sorted descending, indexed by
    feature name.
    """
    if isinstance(model, TREE_BASED_MODELS) and hasattr(model, "feature_importances_"):
        importances = pd.Series(model.feature_importances_, index=feature_names)
        method = "native feature_importances_"

    elif isinstance(model, LogisticRegression):
        # Use absolute standardized coefficients as importance.
        # Features were already scaled during preprocessing, so coefficient
        # magnitude is a fair basis for comparison across features.
        importances = pd.Series(np.abs(model.coef_[0]), index=feature_names)
        method = "absolute standardized coefficients"

    else:
        # Model-agnostic fallback: permutation importance.
        result = permutation_importance(
            model, X_test, y_test, n_repeats=15, random_state=42, scoring="roc_auc"
        )
        importances = pd.Series(result.importances_mean, index=feature_names)
        method = "permutation importance"

    print(f"[explainability] Feature importance computed using: {method}")
    return importances.sort_values(ascending=False)


def try_shap_explanation(model, X_train, X_test, feature_names):
    """
    Attempt to compute SHAP values for extra interpretability where
    practical. Returns a pandas Series of mean absolute SHAP values per
    feature, or None if SHAP isn't applicable/available for this model.
    """
    try:
        import shap

        if isinstance(model, TREE_BASED_MODELS):
            explainer = shap.TreeExplainer(model)
            shap_values = explainer.shap_values(X_test)
            # For binary classifiers, shap_values may be a list [class0, class1]
            if isinstance(shap_values, list):
                shap_values = shap_values[1]
            mean_abs_shap = np.abs(shap_values).mean(axis=0)
            # TreeExplainer can occasionally return an extra dimension for
            # binary classification; flatten defensively.
            mean_abs_shap = np.ravel(mean_abs_shap)[: len(feature_names)]
            return pd.Series(mean_abs_shap, index=feature_names).sort_values(ascending=False)

        elif isinstance(model, LogisticRegression):
            explainer = shap.LinearExplainer(model, X_train)
            shap_values = explainer.shap_values(X_test)
            mean_abs_shap = np.abs(shap_values).mean(axis=0)
            return pd.Series(mean_abs_shap, index=feature_names).sort_values(ascending=False)

        else:
            return None  # Not attempting KernelExplainer here -- too slow for a demo app.

    except Exception as e:
        print(f"[explainability] SHAP explanation skipped ({e}).")
        return None


def plot_feature_importance(importances: pd.Series, save_path=FEATURE_IMPORTANCE_PATH, title="Feature Importance"):
    """Generate and save a horizontal bar chart of feature importances."""
    RESULTS_DIR.mkdir(parents=True, exist_ok=True)
    top = importances.sort_values(ascending=True)  # ascending for horizontal bar plot order

    fig, ax = plt.subplots(figsize=(8, 6))
    ax.barh(top.index, top.values, color="#3b7dd8")
    ax.set_xlabel("Relative Importance")
    ax.set_title(title)
    plt.tight_layout()
    fig.savefig(save_path, dpi=150)
    plt.close(fig)
    print(f"[explainability] Saved feature importance chart -> {save_path}")


def explain_single_prediction(model, feature_names, patient_row: pd.DataFrame, importances: pd.Series, top_n: int = 3):
    """
    Produce a short, human-readable explanation for one patient's prediction,
    highlighting the top contributing features and whether the patient's
    values for those features are elevated/reduced relative to typical
    ranges. Used by the Streamlit app.
    """
    top_features = importances.head(top_n).index.tolist()
    explanations = []
    for feat in top_features:
        value = patient_row[feat].values[0] if feat in patient_row.columns else None
        explanations.append(
            f"- **{feat}** (value entered: {value}) was among the most influential "
            f"factors in this prediction."
        )
    return explanations


def run_explainability_pipeline():
    """Run the full explainability pipeline: compute + plot + save importance."""
    X_train, X_test, y_train, y_test, scaler, target_col = run_preprocessing_pipeline(
        save_outputs=False
    )
    model = joblib.load(BEST_MODEL_PATH)
    feature_names = list(X_train.columns)

    importances = compute_feature_importance(model, X_train, X_test, y_test, feature_names)

    shap_importances = try_shap_explanation(model, X_train, X_test, feature_names)
    if shap_importances is not None:
        print("[explainability] SHAP values computed successfully; using SHAP for the chart.")
        plot_feature_importance(shap_importances, title="Feature Importance (mean |SHAP value|)")
        final_importances = shap_importances
    else:
        plot_feature_importance(importances, title="Feature Importance")
        final_importances = importances

    print("\n[explainability] Top contributing features:")
    print(final_importances.head(5).round(4))

    return final_importances


if __name__ == "__main__":
    run_explainability_pipeline()
