"""
preprocessing.py
=================
Data preprocessing pipeline for the chronic disease (diabetes) risk prediction project.

Responsibilities:
    - Load the raw dataset
    - Inspect and report data quality issues (missing values, duplicates, invalid zeros)
    - Handle missing/invalid values without deleting valid rows
    - Split features (X) and target (y)
    - Perform a train/test split BEFORE scaling (prevents data leakage)
    - Scale numerical features using a scaler fit only on the training data
    - Persist the processed dataset and the fitted scaler for reuse by
      training, evaluation, and the Streamlit app.

This module works with the actual columns found in the uploaded dataset rather
than hard-coding column names, so it is reusable for other tabular chronic
disease datasets that follow a similar "features + binary outcome" layout.
"""

from __future__ import annotations

import json
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
from sklearn.impute import SimpleImputer
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler

# ---------------------------------------------------------------------------
# Project paths (relative to this file, so the project works on any machine)
# ---------------------------------------------------------------------------
PROJECT_ROOT = Path(__file__).resolve().parent.parent
RAW_DATA_PATH = PROJECT_ROOT / "data" / "raw" / "diabetes.csv"
PROCESSED_DATA_PATH = PROJECT_ROOT / "data" / "processed" / "processed_data.csv"
MODELS_DIR = PROJECT_ROOT / "models"
SCALER_PATH = MODELS_DIR / "scaler.pkl"
FEATURE_INFO_PATH = MODELS_DIR / "feature_info.json"

# Target column candidates, checked in order. If none match, the LAST column
# of the dataset is used as the target (a common convention for tabular
# classification datasets), and a warning is printed.
TARGET_CANDIDATES = ["Outcome", "outcome", "target", "Target", "class", "Class", "label", "Label"]

# For the Pima Indians Diabetes dataset specifically, a value of 0 is
# medically impossible for these columns and really represents "missing".
# This list is checked against the ACTUAL columns present in the dataset,
# so it safely does nothing for datasets that don't have these columns.
ZERO_AS_MISSING_CANDIDATES = [
    "Glucose",
    "BloodPressure",
    "SkinThickness",
    "Insulin",
    "BMI",
]


def load_dataset(path: Path = RAW_DATA_PATH) -> pd.DataFrame:
    """Load the raw CSV dataset from disk."""
    if not path.exists():
        raise FileNotFoundError(
            f"Dataset not found at {path}. Please place your CSV file there."
        )
    df = pd.read_csv(path)
    if df.empty:
        raise ValueError(f"Dataset at {path} is empty.")
    return df


def detect_target_column(df: pd.DataFrame) -> str:
    """Detect the target column automatically instead of assuming 'Outcome'."""
    for candidate in TARGET_CANDIDATES:
        if candidate in df.columns:
            return candidate
    # Fall back to the last column, which is the standard convention
    # for this style of tabular dataset.
    fallback = df.columns[-1]
    print(
        f"[preprocessing] WARNING: No standard target column name found. "
        f"Falling back to the last column: '{fallback}'."
    )
    return fallback


def inspect_data_quality(df: pd.DataFrame, target_col: str) -> dict:
    """Print and return a summary of data quality issues found in the dataset."""
    report = {
        "n_rows": int(df.shape[0]),
        "n_columns": int(df.shape[1]),
        "columns": list(df.columns),
        "dtypes": {c: str(t) for c, t in df.dtypes.items()},
        "missing_values": df.isnull().sum().to_dict(),
        "duplicate_rows": int(df.duplicated().sum()),
        "target_column": target_col,
        "target_distribution": df[target_col].value_counts().to_dict(),
    }

    print("=" * 60)
    print("DATA QUALITY REPORT")
    print("=" * 60)
    print(f"Rows: {report['n_rows']}, Columns: {report['n_columns']}")
    print(f"Target column detected: '{target_col}'")
    print(f"Duplicate rows: {report['duplicate_rows']}")
    print("Missing values per column:")
    for col, n in report["missing_values"].items():
        if n > 0:
            print(f"  - {col}: {n}")
    print(f"Target distribution: {report['target_distribution']}")
    print("=" * 60)
    return report


def handle_invalid_zero_values(df: pd.DataFrame) -> pd.DataFrame:
    """
    Treat physiologically-impossible zero values (e.g. Glucose == 0,
    BMI == 0) as missing, ONLY for columns that are actually present in the
    dataset and that plausibly represent such a measurement.

    This does not delete rows -- values are converted to NaN and then
    imputed in `handle_missing_values`, preserving as much data as possible.
    """
    df = df.copy()
    present_cols = [c for c in ZERO_AS_MISSING_CANDIDATES if c in df.columns]
    for col in present_cols:
        n_zero = int((df[col] == 0).sum())
        if n_zero > 0:
            print(
                f"[preprocessing] Treating {n_zero} zero value(s) in '{col}' "
                f"as missing (medically implausible)."
            )
            df[col] = df[col].replace(0, np.nan)
    return df


def handle_missing_values(df: pd.DataFrame, target_col: str) -> pd.DataFrame:
    """
    Impute missing numeric values with the median of each column.
    Median is used (rather than mean) because it is robust to outliers,
    which are common in clinical measurements.
    """
    df = df.copy()
    feature_cols = [c for c in df.columns if c != target_col]
    numeric_cols = df[feature_cols].select_dtypes(include=[np.number]).columns.tolist()

    if numeric_cols:
        imputer = SimpleImputer(strategy="median")
        df[numeric_cols] = imputer.fit_transform(df[numeric_cols])

    remaining_missing = df.isnull().sum().sum()
    if remaining_missing > 0:
        print(
            f"[preprocessing] {remaining_missing} missing value(s) remain in "
            f"non-numeric columns; dropping affected rows as a last resort."
        )
        df = df.dropna()

    return df


def remove_duplicates(df: pd.DataFrame) -> pd.DataFrame:
    """Remove exact duplicate rows."""
    before = df.shape[0]
    df = df.drop_duplicates()
    after = df.shape[0]
    if before != after:
        print(f"[preprocessing] Removed {before - after} duplicate row(s).")
    return df


def split_features_target(df: pd.DataFrame, target_col: str) -> tuple[pd.DataFrame, pd.Series]:
    """Separate the dataframe into features (X) and target (y)."""
    X = df.drop(columns=[target_col])
    y = df[target_col]
    return X, y


def run_preprocessing_pipeline(
    raw_path: Path = RAW_DATA_PATH,
    test_size: float = 0.2,
    random_state: int = 42,
    save_outputs: bool = True,
):
    """
    Run the full preprocessing pipeline end-to-end.

    Returns
    -------
    X_train, X_test, y_train, y_test : pd.DataFrame / pd.Series
        Split and scaled datasets (as DataFrames/Series for readability).
    scaler : StandardScaler
        The scaler fitted ONLY on the training data.
    target_col : str
        Name of the detected target column.
    """
    # 1. Load
    df = load_dataset(raw_path)

    # 2. Detect target
    target_col = detect_target_column(df)

    # 3. Inspect
    inspect_data_quality(df, target_col)

    # 4. Clean
    df = remove_duplicates(df)
    df = handle_invalid_zero_values(df)
    df = handle_missing_values(df, target_col)

    # 5. Split X / y
    X, y = split_features_target(df, target_col)
    feature_names = list(X.columns)

    # 6. Train/test split BEFORE scaling to prevent data leakage.
    #    Stratify on y to preserve class balance in both splits.
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=test_size, random_state=random_state, stratify=y
    )

    # 7. Scale numerical features. Fit ONLY on training data.
    numeric_cols = X_train.select_dtypes(include=[np.number]).columns.tolist()
    scaler = StandardScaler()
    X_train_scaled = X_train.copy()
    X_test_scaled = X_test.copy()
    X_train_scaled[numeric_cols] = scaler.fit_transform(X_train[numeric_cols])
    X_test_scaled[numeric_cols] = scaler.transform(X_test[numeric_cols])

    if save_outputs:
        MODELS_DIR.mkdir(parents=True, exist_ok=True)
        PROCESSED_DATA_PATH.parent.mkdir(parents=True, exist_ok=True)

        # Save the fitted scaler for reuse in evaluation / the Streamlit app
        joblib.dump(scaler, SCALER_PATH)

        # Save feature metadata (names, ranges) so the app can build input
        # widgets dynamically instead of hard-coding column names.
        feature_info = {
            "feature_names": feature_names,
            "target_column": target_col,
            "numeric_columns": numeric_cols,
            "feature_ranges": {
                col: {"min": float(X[col].min()), "max": float(X[col].max()), "mean": float(X[col].mean())}
                for col in feature_names
            },
            "class_labels": sorted(y.unique().tolist()),
        }
        with open(FEATURE_INFO_PATH, "w") as f:
            json.dump(feature_info, f, indent=2)

        # Save a processed (cleaned, unscaled) version of the full dataset
        # for use in the EDA notebook and for transparency.
        processed_df = pd.concat([X, y], axis=1)
        processed_df.to_csv(PROCESSED_DATA_PATH, index=False)

        print(f"[preprocessing] Saved scaler -> {SCALER_PATH}")
        print(f"[preprocessing] Saved feature info -> {FEATURE_INFO_PATH}")
        print(f"[preprocessing] Saved processed dataset -> {PROCESSED_DATA_PATH}")

    print(
        f"[preprocessing] Train shape: {X_train_scaled.shape}, "
        f"Test shape: {X_test_scaled.shape}"
    )

    return X_train_scaled, X_test_scaled, y_train, y_test, scaler, target_col


if __name__ == "__main__":
    run_preprocessing_pipeline()
