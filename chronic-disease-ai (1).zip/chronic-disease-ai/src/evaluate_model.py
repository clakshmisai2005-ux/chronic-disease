"""
evaluate_model.py
==================
Evaluates the saved best model on the held-out test set and produces:
    - a classification report (precision, recall, F1, accuracy)
    - a confusion matrix plot  -> results/confusion_matrix.png
    - an ROC curve plot        -> results/roc_curve.png
    - ROC-AUC score

Uses the SAME preprocessing pipeline (and therefore the same scaler) that
was used during training, so evaluation is done on data prepared exactly
the same way as the training data.
"""

from __future__ import annotations

import joblib
import matplotlib
matplotlib.use("Agg")  # headless backend, safe for scripts/servers
import matplotlib.pyplot as plt
import numpy as np
import seaborn as sns
from sklearn.metrics import (
    ConfusionMatrixDisplay,
    RocCurveDisplay,
    classification_report,
    confusion_matrix,
    roc_auc_score,
    roc_curve,
)

from src.preprocessing import MODELS_DIR, run_preprocessing_pipeline
from src.train_model import BEST_MODEL_PATH, RESULTS_DIR

CONFUSION_MATRIX_PATH = RESULTS_DIR / "confusion_matrix.png"
ROC_CURVE_PATH = RESULTS_DIR / "roc_curve.png"

sns.set_style("whitegrid")


def load_best_model():
    """Load the trained best model from disk."""
    if not BEST_MODEL_PATH.exists():
        raise FileNotFoundError(
            f"No trained model found at {BEST_MODEL_PATH}. Run src/train_model.py first."
        )
    return joblib.load(BEST_MODEL_PATH)


def plot_confusion_matrix(y_true, y_pred, save_path=CONFUSION_MATRIX_PATH):
    """Generate and save a confusion matrix heatmap."""
    cm = confusion_matrix(y_true, y_pred)
    fig, ax = plt.subplots(figsize=(6, 5))
    disp = ConfusionMatrixDisplay(confusion_matrix=cm, display_labels=["No Disease", "Disease"])
    disp.plot(ax=ax, cmap="Blues", colorbar=True)
    ax.set_title("Confusion Matrix - Best Model")
    plt.tight_layout()
    RESULTS_DIR.mkdir(parents=True, exist_ok=True)
    fig.savefig(save_path, dpi=150)
    plt.close(fig)
    print(f"[evaluate_model] Saved confusion matrix -> {save_path}")
    return cm


def plot_roc_curve(y_true, y_proba, save_path=ROC_CURVE_PATH):
    """Generate and save an ROC curve plot."""
    fpr, tpr, _ = roc_curve(y_true, y_proba)
    auc_score = roc_auc_score(y_true, y_proba)

    fig, ax = plt.subplots(figsize=(6, 5))
    RocCurveDisplay(fpr=fpr, tpr=tpr, roc_auc=auc_score).plot(ax=ax)
    ax.plot([0, 1], [0, 1], linestyle="--", color="gray", label="Chance")
    ax.set_title("ROC Curve - Best Model")
    ax.legend(loc="lower right")
    plt.tight_layout()
    RESULTS_DIR.mkdir(parents=True, exist_ok=True)
    fig.savefig(save_path, dpi=150)
    plt.close(fig)
    print(f"[evaluate_model] Saved ROC curve -> {save_path}")
    return auc_score


def run_evaluation():
    """Run the full evaluation pipeline and print a report."""
    # Use the same preprocessing pipeline / scaler as training for a fair,
    # leakage-free evaluation on the identical test split.
    X_train, X_test, y_train, y_test, scaler, target_col = run_preprocessing_pipeline(
        save_outputs=False
    )

    model = load_best_model()
    y_pred = model.predict(X_test)
    y_proba = model.predict_proba(X_test)[:, 1]

    print("\n" + "=" * 60)
    print("MODEL EVALUATION REPORT")
    print("=" * 60)
    print(classification_report(y_test, y_pred, target_names=["No Disease", "Disease"]))

    cm = plot_confusion_matrix(y_test, y_pred)
    auc_score = plot_roc_curve(y_test, y_proba)

    print(f"ROC-AUC: {auc_score:.4f}")
    print("=" * 60)

    return {
        "confusion_matrix": cm,
        "roc_auc": auc_score,
        "classification_report": classification_report(
            y_test, y_pred, target_names=["No Disease", "Disease"], output_dict=True
        ),
    }


if __name__ == "__main__":
    run_evaluation()
