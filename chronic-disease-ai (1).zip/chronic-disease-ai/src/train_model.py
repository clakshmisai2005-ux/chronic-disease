"""
train_model.py
===============
Trains and compares multiple classification algorithms for chronic disease
risk prediction, selects the best-performing model based on cross-validated
ROC-AUC, and saves the winning model + its metadata for later use in
evaluation, explainability, and the Streamlit app.

Models compared:
    - Logistic Regression
    - Decision Tree
    - Random Forest
    - Support Vector Machine (with probability estimates)
    - K-Nearest Neighbors
    - Gradient Boosting

Selection metric: mean cross-validated ROC-AUC on the training set, with
test-set F1-score reported alongside for context. ROC-AUC is preferred here
because chronic disease datasets are commonly class-imbalanced (as this one
is: ~65% / 35%), and ROC-AUC is more informative than accuracy in that case.

IMPORTANT: A high test-set score here reflects performance on this dataset
only. It is NOT a claim of medical accuracy or fitness for clinical
diagnosis -- see the project README and the Streamlit app disclaimer.
"""

from __future__ import annotations

import warnings
from pathlib import Path

import joblib
import pandas as pd
from sklearn.ensemble import GradientBoostingClassifier, RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    accuracy_score,
    f1_score,
    precision_score,
    recall_score,
    roc_auc_score,
)
from sklearn.model_selection import StratifiedKFold, cross_val_score
from sklearn.neighbors import KNeighborsClassifier
from sklearn.svm import SVC
from sklearn.tree import DecisionTreeClassifier

from src.preprocessing import MODELS_DIR, PROJECT_ROOT, run_preprocessing_pipeline

warnings.filterwarnings("ignore")

RESULTS_DIR = PROJECT_ROOT / "results"
BEST_MODEL_PATH = MODELS_DIR / "best_model.pkl"
MODEL_METADATA_PATH = MODELS_DIR / "model_metadata.pkl"
MODEL_COMPARISON_PATH = RESULTS_DIR / "model_comparison.csv"

# Candidate models. random_state fixed everywhere for reproducibility.
CANDIDATE_MODELS = {
    "Logistic Regression": LogisticRegression(max_iter=1000, random_state=42),
    "Decision Tree": DecisionTreeClassifier(random_state=42),
    "Random Forest": RandomForestClassifier(n_estimators=200, random_state=42),
    "Support Vector Machine": SVC(probability=True, random_state=42),
    "K-Nearest Neighbors": KNeighborsClassifier(n_neighbors=7),
    "Gradient Boosting": GradientBoostingClassifier(random_state=42),
}


def evaluate_candidate(model, X_train, y_train, X_test, y_test, cv_folds: int = 5) -> dict:
    """Fit a model and compute cross-validated + held-out test metrics."""
    cv = StratifiedKFold(n_splits=cv_folds, shuffle=True, random_state=42)
    cv_auc_scores = cross_val_score(model, X_train, y_train, cv=cv, scoring="roc_auc")

    model.fit(X_train, y_train)
    y_pred = model.predict(X_test)
    y_proba = model.predict_proba(X_test)[:, 1]

    return {
        "cv_roc_auc_mean": cv_auc_scores.mean(),
        "cv_roc_auc_std": cv_auc_scores.std(),
        "test_accuracy": accuracy_score(y_test, y_pred),
        "test_precision": precision_score(y_test, y_pred, zero_division=0),
        "test_recall": recall_score(y_test, y_pred, zero_division=0),
        "test_f1": f1_score(y_test, y_pred, zero_division=0),
        "test_roc_auc": roc_auc_score(y_test, y_proba),
        "fitted_model": model,
    }


def train_and_compare_models(
    X_train, X_test, y_train, y_test, models: dict | None = None
) -> pd.DataFrame:
    """Train every candidate model and return a comparison DataFrame."""
    models = models or CANDIDATE_MODELS
    rows = []
    fitted_models = {}

    for name, model in models.items():
        print(f"[train_model] Training: {name} ...")
        result = evaluate_candidate(model, X_train, y_train, X_test, y_test)
        fitted_models[name] = result.pop("fitted_model")
        result["model"] = name
        rows.append(result)

    comparison_df = pd.DataFrame(rows).set_index("model")
    comparison_df = comparison_df[
        [
            "cv_roc_auc_mean",
            "cv_roc_auc_std",
            "test_accuracy",
            "test_precision",
            "test_recall",
            "test_f1",
            "test_roc_auc",
        ]
    ].sort_values("cv_roc_auc_mean", ascending=False)

    return comparison_df, fitted_models


def select_best_model(comparison_df: pd.DataFrame, fitted_models: dict, metric: str = "cv_roc_auc_mean"):
    """
    Select the best model based on the given metric (default: cross-validated
    ROC-AUC, which is more robust to class imbalance and less prone to
    overfitting to a single train/test split than raw test accuracy).
    """
    best_name = comparison_df[metric].idxmax()
    best_model = fitted_models[best_name]
    best_row = comparison_df.loc[best_name]
    return best_name, best_model, best_row


def run_training_pipeline():
    """Run preprocessing, train all candidate models, and save the best one."""
    RESULTS_DIR.mkdir(parents=True, exist_ok=True)
    MODELS_DIR.mkdir(parents=True, exist_ok=True)

    X_train, X_test, y_train, y_test, scaler, target_col = run_preprocessing_pipeline()

    comparison_df, fitted_models = train_and_compare_models(X_train, X_test, y_train, y_test)
    comparison_df.to_csv(MODEL_COMPARISON_PATH)
    print("\n[train_model] Model comparison (sorted by CV ROC-AUC):")
    print(comparison_df.round(4))

    best_name, best_model, best_row = select_best_model(comparison_df, fitted_models)
    print(f"\n[train_model] Best model selected: {best_name}")
    print(
        f"[train_model] CV ROC-AUC: {best_row['cv_roc_auc_mean']:.4f} "
        f"(+/- {best_row['cv_roc_auc_std']:.4f}), Test F1: {best_row['test_f1']:.4f}"
    )

    joblib.dump(best_model, BEST_MODEL_PATH)

    metadata = {
        "model_name": best_name,
        "feature_names": list(X_train.columns),
        "target_column": target_col,
        "metrics": best_row.to_dict(),
        "all_model_metrics": comparison_df.to_dict(orient="index"),
        "selection_metric": "cv_roc_auc_mean",
    }
    joblib.dump(metadata, MODEL_METADATA_PATH)

    print(f"[train_model] Saved best model -> {BEST_MODEL_PATH}")
    print(f"[train_model] Saved model metadata -> {MODEL_METADATA_PATH}")
    print(f"[train_model] Saved model comparison table -> {MODEL_COMPARISON_PATH}")

    return best_name, best_model, comparison_df, (X_train, X_test, y_train, y_test)


if __name__ == "__main__":
    run_training_pipeline()
