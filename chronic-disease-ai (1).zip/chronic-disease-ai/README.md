# AI-Driven Predictive Analytics for Early Diagnosis and Personalized Treatment in Chronic Diseases

A machine-learning based decision-support system that estimates chronic disease
(diabetes) risk from patient measurements, explains which factors drove each
prediction, and offers general, educational lifestyle recommendations — wrapped
in an interactive Streamlit dashboard.

> ⚠️ **This is an academic/research project, not a medical device.** It does
> not diagnose disease and must never replace consultation with a qualified
> healthcare professional. See [Medical Disclaimer](#medical-disclaimer).

---

## 1. Abstract

Chronic diseases such as diabetes often progress silently before diagnosis,
and early risk identification can meaningfully improve outcomes. This project
builds an end-to-end machine learning pipeline — from data preprocessing
through model comparison, evaluation, explainability, and personalized
lifestyle guidance — and exposes it through an interactive web dashboard. The
system compares six classification algorithms, selects the best-performing
one using cross-validated ROC-AUC, and explains its predictions using
feature-importance and SHAP-based techniques so results are transparent
rather than a "black box."

## 2. Problem Statement

Early-stage chronic disease indicators are often present in routine health
measurements, but manually correlating many variables with disease risk is
difficult. There is a need for a tool that can (a) flag elevated risk from
easily-collected patient data, (b) explain *why* it flagged that risk, and
(c) suggest general, non-prescriptive lifestyle actions — all while being
transparent about its limitations.

## 3. Objectives

- Preprocess real patient data, handling missing/invalid values correctly.
- Explore the dataset to understand feature distributions and relationships.
- Train and fairly compare multiple ML classification algorithms.
- Select and persist the best-performing model with justification.
- Evaluate the model with standard classification metrics.
- Provide explainable AI so predictions are interpretable, not opaque.
- Generate general, educational, non-prescriptive personalized recommendations.
- Deliver all of the above through an accessible Streamlit web interface.

## 4. Proposed System

The system follows a linear pipeline: **raw data → cleaning → EDA → model
training & comparison → evaluation → explainability → recommendation
generation → dashboard**. Each stage is implemented as a reusable Python
module in `src/`, and the same modules are used by both the Jupyter
notebooks (for narrated exploration) and the Streamlit app (for live
inference), so there is a single source of truth for the logic.

## 5. System Architecture

```
Raw CSV → preprocessing.py → (cleaned, scaled data) → train_model.py
        → best_model.pkl + scaler.pkl + model_metadata.pkl
        → evaluate_model.py (metrics + plots)
        → explainability.py (feature importance / SHAP)
        → recommendations.py (rule-based lifestyle guidance)
        → app/app.py (Streamlit dashboard, ties everything together)
```

## 6. Dataset Description

**File:** `data/raw/diabetes.csv` — the Pima Indians Diabetes Dataset (768
rows, 9 columns).

> **Note on this file:** the ZIP uploaded for this project contained an
> empty placeholder `diabetes.csv` (0 bytes) and empty placeholder Python
> files. Since there was no actual data to inspect, this standard, widely
> used academic diabetes dataset was used to populate `data/raw/diabetes.csv`
> so the pipeline has real data to run against. If you have your own dataset,
> replace this file — the pipeline auto-detects the target column and
> feature names rather than hard-coding "Outcome", so it will adapt.

| Column | Description |
|---|---|
| Pregnancies | Number of times pregnant |
| Glucose | Plasma glucose concentration (2-hr oral glucose tolerance test) |
| BloodPressure | Diastolic blood pressure (mm Hg) |
| SkinThickness | Triceps skinfold thickness (mm) |
| Insulin | 2-hour serum insulin (mu U/ml) |
| BMI | Body mass index |
| DiabetesPedigreeFunction | Diabetes likelihood based on family history |
| Age | Age in years |
| **Outcome** (target) | 0 = no diabetes, 1 = diabetes |

Data quality notes (see `notebooks/01_eda.ipynb` for full detail): no
standard NaNs, but `Glucose`, `BloodPressure`, `SkinThickness`, `Insulin`,
and `BMI` contain medically-implausible zero values that are treated as
missing and median-imputed. The target is imbalanced (~65% / 35%).

## 7. Technologies Used

- **Language:** Python 3.11+
- **Data handling:** pandas, numpy
- **Machine learning:** scikit-learn
- **Explainability:** SHAP, permutation importance, model coefficients
- **Visualization:** matplotlib, seaborn
- **Web app:** Streamlit
- **Notebooks:** Jupyter

## 8. Project Structure

```
chronic-disease-ai/
├── data/
│   ├── raw/diabetes.csv              # Raw dataset
│   └── processed/processed_data.csv  # Cleaned dataset (generated)
├── models/
│   ├── best_model.pkl                # Trained best model (generated)
│   ├── scaler.pkl                    # Fitted StandardScaler (generated)
│   ├── model_metadata.pkl            # Best model name + metrics (generated)
│   └── feature_info.json             # Feature names/ranges for the app (generated)
├── notebooks/
│   ├── 01_eda.ipynb                  # Exploratory Data Analysis
│   └── 02_model_training.ipynb       # Training, comparison, evaluation, explainability
├── src/
│   ├── preprocessing.py              # Cleaning, splitting, scaling
│   ├── train_model.py                # Multi-model training & comparison
│   ├── evaluate_model.py             # Metrics, confusion matrix, ROC curve
│   ├── explainability.py             # Feature importance / SHAP
│   └── recommendations.py            # Rule-based lifestyle guidance
├── app/
│   └── app.py                        # Streamlit dashboard (5 pages)
├── results/                          # Generated plots & comparison table
├── requirements.txt
└── README.md
```

## 9. Methodology

1. **Preprocessing** (`src/preprocessing.py`): load data, auto-detect the
   target column, treat medically-implausible zeros as missing, median-impute,
   split train/test (stratified, 80/20) **before** scaling to prevent data
   leakage, then fit a `StandardScaler` on the training set only.
2. **EDA** (`notebooks/01_eda.ipynb`): distributions, missingness, duplicates,
   correlations, and feature-vs-target relationships.
3. **Training** (`src/train_model.py`): train 6 algorithms, compare with
   5-fold stratified cross-validation, select the best by CV ROC-AUC.
4. **Evaluation** (`src/evaluate_model.py`): classification report, confusion
   matrix, ROC curve on the held-out test set.
5. **Explainability** (`src/explainability.py`): importance method chosen by
   model type (native importances for tree models, coefficients for linear
   models, permutation importance otherwise), with SHAP layered on top when
   compatible.
6. **Recommendations** (`src/recommendations.py`): rule-based, non-prescriptive
   lifestyle tips triggered by elevated values in the top contributing features.

## 10. Machine Learning Algorithms Compared

Logistic Regression · Decision Tree · Random Forest · Support Vector Machine
· K-Nearest Neighbors · Gradient Boosting

## 11. Evaluation Metrics

Accuracy, Precision, Recall, F1-score, ROC-AUC — reported both as
cross-validated (training set) and held-out test-set values, since accuracy
alone is misleading on an imbalanced target.

## 12. Explainable AI

The app shows which patient features most influenced a given prediction, and
a global feature-importance chart (`results/feature_importance.png`).
**Feature importance reflects statistical association learned by the model —
it does not establish that a feature causes the outcome.**

## 13. Personalized Recommendations

Based on predicted risk and the top contributing features, the app surfaces
general, educational lifestyle suggestions (diet, activity, monitoring,
professional consultation). The system **never** prescribes medication,
dosages, or a diagnosis.

## 14. How to Install

```bash
cd chronic-disease-ai
python -m venv venv
source venv/bin/activate      # Windows: venv\Scripts\activate
pip install -r requirements.txt
```

## 15. How to Run

```bash
# 1. Preprocess the data (optional standalone run — training runs this automatically)
python -m src.preprocessing

# 2. Train and compare models, save the best one
python -m src.train_model

# 3. Evaluate the saved best model (confusion matrix + ROC curve)
python -m src.evaluate_model

# 4. Generate the explainability chart
python -m src.explainability

# 5. Launch the dashboard
streamlit run app/app.py
```

## 16. Example Usage

1. Run steps 1–4 above once to generate `models/` and `results/` artifacts.
2. Launch the app (`streamlit run app/app.py`) and open the printed local URL.
3. On the **Risk Prediction** page, enter patient values (defaults are
   pre-filled with dataset averages) and click **Predict Risk**.
4. Visit **Explainability** to see which features drove that prediction.
5. Visit **Recommendations** for general lifestyle guidance based on the result.
6. Visit **Model Performance** to review accuracy/precision/recall/F1/ROC-AUC
   and the confusion matrix / ROC curve.

## 17. Results

Model comparison (5-fold cross-validated ROC-AUC on training data, sorted
descending — full table in `results/model_comparison.csv`):

| Model | CV ROC-AUC | Test Accuracy | Test F1 | Test ROC-AUC |
|---|---|---|---|---|
| **Logistic Regression** ⭐ | **0.843** | 0.708 | 0.545 | 0.813 |
| Support Vector Machine | 0.834 | 0.740 | 0.600 | 0.796 |
| Random Forest | 0.822 | 0.740 | 0.600 | 0.816 |
| Gradient Boosting | 0.818 | 0.760 | 0.626 | 0.830 |
| K-Nearest Neighbors | 0.802 | 0.727 | 0.588 | 0.790 |
| Decision Tree | 0.642 | 0.682 | 0.515 | 0.636 |

**Best model: Logistic Regression**, selected on mean cross-validated
ROC-AUC — the most robust metric here given the class imbalance and small
dataset size (768 rows), since it averages over 5 different train/validation
splits rather than depending on one lucky/unlucky split.

**Top contributing features** (via SHAP, see `results/feature_importance.png`):
`Glucose` (by a wide margin), followed by `BMI`, `Pregnancies`,
`DiabetesPedigreeFunction`, and `Age` — consistent with established clinical
risk factors for type 2 diabetes, which is a reassuring sanity check but
**not proof of medical validity**.

## 18. Limitations

- Trained on a single, relatively small (768-row) public dataset — results
  will not generalize to other populations without retraining/validation.
- Zero-as-missing imputation is a simplification of true missing-data handling.
- No external clinical validation was performed.
- Explainability shows association, not causation.
- Not tested for fairness/bias across demographic subgroups.

## 19. Future Scope

- Validate on a larger, more diverse, and/or multi-site clinical dataset.
- Add hyperparameter tuning (e.g. grid/random search) for each candidate model.
- Extend to other chronic diseases (e.g. heart disease, CKD) with the same pipeline.
- Add fairness/bias auditing across demographic groups.
- Add model monitoring for data/concept drift if deployed longitudinally.

## 20. Medical Disclaimer

This project is a **research and educational decision-support tool**. It is
**not** a certified medical device, does **not** provide a medical diagnosis,
and must **not** be used as a substitute for professional medical advice,
diagnosis, or treatment. Always consult a qualified healthcare provider with
questions about a medical condition. No medications or dosages are suggested
anywhere in this system.
